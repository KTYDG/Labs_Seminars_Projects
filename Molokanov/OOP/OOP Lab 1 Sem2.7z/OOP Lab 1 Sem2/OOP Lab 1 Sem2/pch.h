#ifndef PCH_H
#define PCH_H

#include <iostream>
#include <iomanip> // setw, setfill, left
#include <fstream> // input
#include <string>
#include <vector>
//#include <locale>
#include <codecvt> // codecvt_utf8
#include <conio.h> // _getch
#include <algorithm> // sort
using namespace std;


#endif //PCH_H
